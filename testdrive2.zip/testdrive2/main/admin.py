from django.contrib import admin
from .models import Drive


admin.site.register(Drive)
